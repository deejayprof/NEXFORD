README.md
# PCA Implementation and Logistic Regression on Cancer Dataset

## Description
This project applies Principal Component Analysis (PCA) to the breast cancer dataset available from sklearn.datasets. The objectives include dimensionality reduction to identify essential variables and an optional bonus task of implementing logistic regression for prediction.

## Features
  •	Data Import and Preparation:
	  - Load the breast cancer dataset from sklearn.datasets.
	  - Perform necessary preprocessing, including scaling the data for PCA.
	•	Principal Component Analysis (PCA):
	  - Implement PCA to identify essential variables.
	  - Reduce the dataset to 2 PCA components for dimensionality reduction.
	•	Logistic Regression:
	  -	Implement logistic regression on the reduced dataset for classification and prediction.


#Files included
	•	Milestone_Assignment_2_PCA.ipynb: Python script for implementing PCA and optional logistic regression.
	•	Principal Component Analysis_README.md: Instructions for understanding and running the project.
	
#How to Run
	1. Download the Repository:
	•	Unzip the provided file.
	3.	Run the Script:
	•	Execute Milestone_Assignment_2_PCA.ipynb in your preferred Python environment (e.g., Jupyter Notebook or terminal).