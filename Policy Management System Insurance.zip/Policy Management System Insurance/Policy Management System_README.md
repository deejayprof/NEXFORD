## Policy Management System

Overview

This project demonstrates the creation of a policy management system for an insurance company. The system manages policyholders, products, and payments with object-oriented programming principles. It includes methods for registering, updating, and suspending policyholders and products, as well as handling payment processing, reminders, and penalties.

## Project Structure

The project consists of the following Python files:

## policyholder.py:
Contains the Policyholder class.
Methods for:
Registering a policyholder.
Suspending or reactivating policyholders.
Displaying policyholder details.

## product.py:
Contains the Product class.
Methods for:
Creating and updating policy products.
Suspending products.
Displaying product details.

## payment.py:
Contains the Payment class.
Methods for:
Processing payments.
Sending reminders for unpaid payments.
Applying penalties to overdue payments.
Displaying payment details.
## Policy_management_system.py:
Demonstrates the functionality of the system by:
Creating two policyholders and two products.
Processing payments for the policyholders.
Displaying their account, payment, and product details.

## Instructions to Run the Project

Ensure Python is Installed:
Install Python 3.x on your system if it’s not already installed.
Download Project Files:
Download all files (policyholder.py, product.py, payment.py, Policy_management_system.py) into the same directory.
Run the Policy_management_system.py File:
Open a terminal or command prompt.
Navigate to the directory containing the files.
Run the following command:
python Policy_management_system.py
Expected Output:
The script will demonstrate the following:
Registering two policyholders.
Creating two products.
Processing payments for the policyholders.
Displaying the details of policyholders, their payments, and the products they purchased.
