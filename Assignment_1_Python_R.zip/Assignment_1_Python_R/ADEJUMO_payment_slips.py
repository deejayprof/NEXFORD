#Project title: Highridge Construction Company Payment Slips 

import random

# Step 1: Create a list of 400 workers dynamically
workers = [
    {
        "worker_id": i + 1,
        "name": f"Worker_{i + 1}",
        "salary": random.randint(5000, 35000),  # Random salary between 5000 and 35000
        "gender": random.choice(["Male", "Female"]),
    }
    for i in range(400)
]

# Step 2: Generate payment slips using a for loop
def generate_payment_slips(workers):
    try:
        payment_slips = []
        for worker in workers:
            worker_id = worker["worker_id"]
            name = worker["name"]
            salary = worker["salary"]
            gender = worker["gender"]

            # Apply conditions for Employee level
            if 10000 < salary < 20000:
                employee_level = "A1"
            elif 7500 < salary < 30000 and gender == "Female":
                employee_level = "A5-F"
            else:
                employee_level = "General"

            # Create the payment slip
            payment_slip = {
                "Worker ID": worker_id,
                "Name": name,
                "Salary": salary,
                "Gender": gender,
                "Employee Level": employee_level,
            }
            payment_slips.append(payment_slip)

        return payment_slips
    except Exception as e:
        print(f"An error occurred while generating payment slips: {e}")
        return []

# Step 3: Call the function and display the payment slips
payment_slips = generate_payment_slips(workers)

# Output some example payment slips
for slip in payment_slips[:10]:  # Display first 10 slips
    print(slip)
