#Project title: Highridge Construction Company Payment Slips 

# Step 1: Create a list of 400 workers dynamically 
set.seed(123)  # For reproducibility
workers <- data.frame(
  worker_id = 1:400,
  name = paste0("Worker_", 1:400),
  salary = sample(5000:35000, 400, replace = TRUE),
  gender = sample(c("Male", "Female"), 400, replace = TRUE)
)

# Step 2: Generate payment slips using a for loop
generate_payment_slips <- function(workers) {
  tryCatch({
    workers$employee_level <- sapply(1:nrow(workers), function(i) {
      salary <- workers$salary[i]
      gender <- workers$gender[i]
      
      if (salary > 10000 && salary < 20000) {
        return("A1")
      } else if (salary > 7500 && salary < 30000 && gender == "Female") {
        return("A5-F")
      } else {
        return("General")
      }
    })
    return(workers)
  }, error = function(e) {
    print(paste("An error occurred:", e))
    return(NULL)
  })
}

# Step 3: Call the function and display the payment slips
payment_slips <- generate_payment_slips(workers)
head(payment_slips, 10)  # Display the first 10 payment slips
