README.md
# Netflix Data Visualization

## Description
This project analyzes Netflix’s dataset for visual analytics and insights. The tasks include data preparation, cleaning, exploration, visualization, and integration of R and Python code to gain insights about popular genres, ratings distribution

## Features
- Import salary data from a CSV file.
- Retrieve employee details using Python.
- Handle errors gracefully.
- Export employee details to a CSV file and zip it.
- Use R to unzip the folder and display data.

## How to Use

## Python
Run the Jupyter Notebook (Salary_function.ipynb):
Import salary data.
Use get_employee_details() to retrieve employee details.
Use export_employee_to_csv() to export data.

## R
	1.	Open the R script Netflix_data.R in RStudio.
	2.	Setup Instructions:
	•	load necessary libraries ("dplyr", "tidyr", "ggplot2")
	3.	Execution:
	•	Run the script to:
	•	Unzip the dataset .
	•	Clean the data
	•	Visualize the data

Netflix_data.ipynb: Python notebook.
Netflix_data.R: R script.
README.md: Instructions.


#Files included
Files Included
	•	Netflix_data.ipynb: Python script for  data import, cleaning, exploration and     visualization.
	•	Netflix_data.R: R script for generating additional visualizations.
	•	netflix_data.csv: Original netflix dataset before cleaning and processing.
	•	cleaned_netflix_data.csv: Cleaned dataset after processing.
	•	README.md: Instructions for setting up and running the project.