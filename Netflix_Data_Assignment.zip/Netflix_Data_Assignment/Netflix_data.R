


# Load necessary package

library(dplyr)
library(ggplot2)
library(tidyr)
library(dplyr)



# 1. Unzipping file in R and renaming
zip_file <- "netflix_data.csv.zip"
output_dir <- "unzipped_files"  # Specify a valid directory name

# Ensure the output directory exists
if (!dir.exists(output_dir)) {
  dir.create(output_dir)
}

# Unzip the file
unzip(zipfile = zip_file, exdir = output_dir)

# Get the list of extracted files (exclude directories)
extracted_files <- list.files(output_dir, full.names = TRUE)
extracted_files <- extracted_files[file.info(extracted_files)$isdir == FALSE]

# Rename the extracted file to the desired name
desired_file <- file.path(output_dir, "netflix_data.csv")
if (length(extracted_files) > 0) {
  file.rename(extracted_files[1], desired_file)
  cat("File unzipped and renamed to:", desired_file, "\n")
} else {
  cat("No valid file found to rename.\n")
}


#2. Data Cleaning: Addressing missing values in the dataset.

# Load the newly unzipped dataset
data <- read.csv("unzipped_files/netflix_data.csv")

# Display missing values summary
cat("Missing values per column:\n")
colSums(is.na(data))

#colSums(is.na(data))
#show_id         type        title     director         cast      country   date_added 
#0            0            0            0            0            0            0 
#release_year       rating     duration    listed_in  description 
#0            0            0            0            0 


# Address missing values if any, but there seems to be no missing values.
# Strategy 1: Fill missing categorical values with "Unknown"
categorical_columns <- c("type", "director", "cast", "country", "rating", "listed_in", "description", "title", "date_added", "release_year")
data[categorical_columns] <- lapply(data[categorical_columns], function(x) {
  ifelse(is.na(x), "Unknown", x)
})

# Strategy 2: Drop rows with missing values in critical fields (if necessary)
data <- data %>% filter(!is.na(title) & !is.na(release_year))

# Save the cleaned dataset
write.csv(data, "cleaned_netflix_data.csv", row.names = FALSE)

# Confirm no missing values remain
cat("Missing values after cleaning:\n")
colSums(is.na(data))


###3. Perform various data exploration tasks, including describing the data and conducting statistical analysis
##Summarize the Dataset
# View the structure of the dataset
data <- read.csv("cleaned_netflix_data.csv")
str(data)

# Get a summary of numerical columns
summary(data)

# Check the number of rows and columns
cat("Number of Rows:", nrow(data), "\n")
cat("Number of Columns:", ncol(data), "\n")

##Check for Missing Values
# Count missing values per column
missing_values <- colSums(is.na(data))
cat("Missing Values per Column:\n")
print(missing_values)


#Numerical Columns
# Descriptive statistics for numerical columns (e.g., duration, release_year)
numeric_columns <- c("release_year") 
data %>%
  select(all_of(numeric_columns)) %>%
  summarise(across(everything(), list(
    mean = ~mean(., na.rm = TRUE),
    median = ~median(., na.rm = TRUE),
    sd = ~sd(., na.rm = TRUE),
    min = ~min(., na.rm = TRUE),
    max = ~max(., na.rm = TRUE)
  )))


### Count unique values and most frequent values for categorical columns
categorical_columns <- c("type", "rating", "listed_in") 
for (col in categorical_columns) {
  cat("\nColumn:", col, "\n")
  cat("Unique Values:", length(unique(data[[col]])), "\n")
  print(table(data[[col]]))
}


### Correlation matrix for show_id and release_year
correlation_matrix <- cor(data[ , sapply(data, is.numeric)], use = "complete.obs")
print(correlation_matrix)


# Split the 'listed_in' column and count occurrences
genre_data <- data %>%
  select(listed_in) %>%
  separate_rows(listed_in, sep = ", ") %>%
  group_by(listed_in) %>%
  summarise(Count = n()) %>%
  arrange(desc(Count))

print(genre_data)



###4. VISUALIZATION OF MOST WATCHED GENRES, RATINGS, BASED ON RELEASE DATES, ETC
#Top 20 Most Watched Genres
genre_data <- data %>%
  select(listed_in) %>%
  separate_rows(listed_in, sep = ", ") %>%
  group_by(listed_in) %>%
  summarise(Count = n()) %>%
  arrange(desc(Count)) %>%
  slice_head(n = 20) # Select the top 20 genres

# Create bar plot for the top 20 genres
ggplot(genre_data, aes(x = reorder(listed_in, -Count), y = Count)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  labs(title = "Top 20 Most Watched Genres", x = "Genre", y = "Frequency") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

###VIZUALIZATION OF RATINGS
# Summarize ratings frequency
ratings_data <- data %>%
  group_by(rating) %>%
  summarise(Count = n()) %>%
  arrange(desc(Count))

# Create bar plot
ggplot(ratings_data, aes(x = reorder(rating, -Count), y = Count)) +
  geom_bar(stat = "identity", fill = "red") +
  theme_minimal() +
  labs(title = "Distribution by Ratings", x = "Rating", y = "Frequency") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


####WE CAN ALSO SEE DISTRIBUTION BASED ON RELEASE DATE
# Summarize based on release year
###Filter for Release Years with Frequency Above 50
# Summarize based on release year and filter for frequencies above 50
release_year_data_filtered <- data %>%
  group_by(release_year) %>%
  summarise(Count = n()) %>%
  filter(Count > 50) %>%  # Keep only release years with frequency > 50
  arrange(desc(Count))

# Create bar plot for filtered data
ggplot(release_year_data_filtered, aes(x = reorder(release_year, -Count), y = Count)) +
  geom_bar(stat = "identity", fill = "green3") +
  theme_minimal() +
  labs(
    title = "Release Year Distribution (Frequency > 50)",
    x = "Release Year",
    y = "Frequency"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
