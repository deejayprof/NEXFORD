README.md
# Flask Survey Application

## Description
This project is a Flask-based web application for collecting user survey data, storing it in MongoDB, and performing data analysis. The application is hosted on an AWS EC2 instance. The workflow includes data processing, cleaning, analysis, and visualization, with exported results ready for presentation.

## Project Files
1.	app_individual2.py
	•	The main Flask application for collecting user survey data and storing it in MongoDB.
	•	Accessible via: http://3.17.134.223:5000
	•	Setup:
	•	This file contains the Flask app code and connects to MongoDB using credentials stored in a .env file. The environment variable MONGO_URI is loaded using python-dotenv.
	•	To enable external access, the app is run with host='0.0.0.0'.
	
2.	app_500_participants.py
	•	Bulk data generator script for creating survey data for 500 participants.
	
3.	MongoDB_to_csv.py
	•	A script to extract data from MongoDB and export it to a CSV file.
	
4.	Flask_Healthcare_Application_Survey.csv
	•	The raw survey data exported from MongoDB.
	
5.	Cleaned_Flask_Healthcare_Application_Survey.csv
	•	The cleaned version of the survey data, with missing values and NA removed.
	
6.	Flask_Healthcare_Application.ipynb
	•	A Jupyter notebook for:
	•	Loading the cleaned survey data.
	•	Performing data visualizations:
	•	Ages with the Highest Income
	•	Gender Distribution Across Spending Categories
	•	Exporting visualizations as PNG files for presentations.
	
7.	Visualization PNG Files
	•	ages_highest_income.png: Visualization of ages with the highest income.
	•	gender_spending_distribution.png: Visualization of gender distribution across spending categories.
	
8.	requirements.txt
	•	A file containing the Python dependencies required for the project.
	
9.	Templates Folder (templates/)
	•	Contains form.html, the HTML template for the Flask web application.


#Environment Setup

Python Dependencies
	•	Install the required dependencies using requirements.txt.
	
Environment Variables
  •	Step 3: Create the .env File
  The application requires a .env file to store the MongoDB connection URI securely.
	Add the following content to the .env file:
	•	Use a .env file to store sensitive MongoDB credentials:
	MONGO_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/<database>?retryWrites=true&w=majority
	  Replace:
	  •	<username>: Your MongoDB username.
	  •	<password>: Your MongoDB password.
	  •	<cluster>: Your MongoDB cluster name.
	  •	<database>: Your database name.

#Instructions for setting up the .env file, installing dependencies, and running the Flask application	
1. Place your `.env` file in the same directory as `app_individual.py`.
2. Add your MongoDB URI to the `.env` file.
3. Run the Flask application:
   $ python3 -m venv venv
   $ source venv/bin/activate
   $ pip install -r requirements.txt
   $ python app_individual2.py
   For local testing: http://127.0.0.1:5000
4. Access the application at `http://3.17.134.223:5000`.


#Instructions for running the Flask App

1. Access the Web Application
	1.	Open a web browser and navigate to the hosted Flask app:
	•	http://3.17.134.223:5000
	2.	Fill out the form with survey details and submit.
	
2. Bulk Data Generation
	1.	Run app_500_participants.py to generate data for 500 participants.
      python3 MongoDB_to_csv.py
      
3. Extract Data from MongoDB
	1.	Run MongoDB_to_csv.py to extract survey data from MongoDB.
	2.	The data will be saved as Flask_Healthcare_Application_Survey.csv.
	
4. Load Data on Jupyter Notebook
	1.	Open Flask_Healthcare_Application.ipynb in Jupyter Notebook.
	
5. Clean Data
	1.	Open the extracted CSV file in jupyter Notebook.
	2.	Clean missing and NA values.
	3.	Save the file as Cleaned_Flask_Healthcare_Application_Survey.csv.
	
6. Data Analysis and Visualization
	1.Run the notebook cells to:
	•	Load the cleaned data.
	•	Analyze and visualize the data.
	•	Export visualizations as PNG files.
7. Application hosted on AWS
	1.	Use the provided public IP to access the application:
      http://3.17.134.223:5000
      
