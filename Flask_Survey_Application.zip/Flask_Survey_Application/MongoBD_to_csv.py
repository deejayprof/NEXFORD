import pymongo
from pymongo import MongoClient
import pandas as pd
import csv

# MongoDB connection details
MONGO_URI = "mongodb+srv://sadeju2:Samdej01-17@samsonnexford.4ibso.mongodb.net/?retryWrites=true&w=majority&appName=SamsonNEXFORD"
client = pymongo.MongoClient(MONGO_URI)
db = client["SAMSON"]  # Database name
collection = db["NEXFORD"]  # Collection name


# Fetch data from MongoDB
data = list(collection.find())


# User class definition
class User:
    def __init__(self, age, gender, income, expenses):
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    def to_dict(self):
        return {
            "Age": self.age,
            "Gender": self.gender,
            "Income": self.income,
            **self.expenses
        }


# Create User objects from MongoDB data
users = []
for record in data:
    age = record.get('age')
    gender = record.get('gender')
    income = record.get('income')
    expenses = record.get('expenses', {})  # Flatten expenses
    users.append(User(age, gender, income, expenses))


# Store data in a CSV file
csv_file = "Flask_Healthcare_Application_Survey.csv"
with open(csv_file, mode='w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=["Age", "Gender", "Income", "Utilities", "Entertainment", "School Fees", "Shopping", "Healthcare"])
    writer.writeheader()
    for user in users:
        writer.writerow(user.to_dict())

print(f"Data saved to {csv_file}")


