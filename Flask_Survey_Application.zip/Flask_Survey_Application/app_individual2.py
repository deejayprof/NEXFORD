from flask import Flask, render_template, request
from pymongo import MongoClient
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

# MongoDB connection details
MONGO_URI = os.getenv("MONGO_URI")
if not MONGO_URI:
    raise ValueError("MongoDB URI not found. Set the MONGO_URI environment variable.")

client = MongoClient(MONGO_URI)
db = client['SAMSON']  # Database name
collection = db['NEXFORD']  # Collection name

@app.route('/')
def index():
    """
    Render the form page.
    Ensure you have a 'form.html' file in the 'templates' folder.
    """
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    """
    Handle form submissions and save the data to MongoDB.
    """
    # Capture form data
    age = request.form.get('age')
    gender = request.form.get('gender')
    income = request.form.get('income')

    # Capture expense details
    expenses = {}
    for category in ['Utilities', 'Entertainment', 'School Fees', 'Shopping', 'Healthcare']:
        if request.form.get(f'{category}_amount'):
            expenses[category] = float(request.form.get(f'{category}_amount'))

    # Validate data
    if not age or not gender or not income:
        return "Missing required fields. Please fill out all required fields.", 400

    # Insert data into MongoDB
    user_data = {
        "age": int(age),
        "gender": gender,
        "income": float(income),
        "expenses": expenses
    }
    collection.insert_one(user_data)

    return "Form submitted and data saved to MongoDB successfully!"

if __name__ == '__main__':
    # Bind to all interfaces to allow external access
    app.run(host='0.0.0.0', port=5000, debug=False)