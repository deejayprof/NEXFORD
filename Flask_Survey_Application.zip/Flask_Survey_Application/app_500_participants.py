from pymongo import MongoClient
import random

# MongoDB connection details
MONGO_URI = "mongodb+srv://sadeju2:Samdej01-17@samsonnexford.4ibso.mongodb.net/?retryWrites=true&w=majority&appName=SamsonNEXFORD"
client = MongoClient(MONGO_URI)
db = client['SAMSON']  # Database name
collection = db['NEXFORD']  # Collection name

# Function to generate random data
def generate_random_data(n=10):
    genders = ['Male', 'Female', 'Other']
    expense_categories = ['Utilities', 'Entertainment', 'School Fees', 'Shopping', 'Healthcare']

    data_list = []
    for _ in range(n):
        # Generate random user data
        age = random.randint(18, 60)
        gender = random.choice(genders)
        income = random.randint(2000, 20000)

        # Generate random expenses
        expenses = {category: random.randint(50, 500) for category in expense_categories}

        # Create a document
        user_data = {
            "age": age,
            "gender": gender,
            "income": income,
            "expenses": expenses
        }
        data_list.append(user_data)
    return data_list

# Insert multiple records into MongoDB
number_of_records = 500  # Specify how many records you want to create
records = generate_random_data(number_of_records)
collection.insert_many(records)

print(f"Inserted {number_of_records} records into the MongoDB collection.")