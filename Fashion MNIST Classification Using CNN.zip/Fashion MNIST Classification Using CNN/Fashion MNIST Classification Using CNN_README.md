README.md
# Fashion MNIST Classification Using CNN

## Description
This project implements a Convolutional Neural Network (CNN) using Keras in Python and R to classify images from the Fashion MNIST dataset. The CNN is built with six layers, and predictions are made for at ten sample images from the dataset. 

## Features
Python Implementation and how to run
	1. Use the GitHub link to access the zip file
	2. Download the zip file Fashion_MNIST_Classification.ipynb.zip
	3. Open the Fashion_MNIST_Classification.ipynb file in Jupyter Notebook or your preferred IDE.
	4. Execute the cells to load the dataset, build, train, and evaluate the CNN.
	5.	Make Predictions:The notebook includes code to predict and display results for at ten sample images.
	6.	Visualize Results: Check the predicted labels against the true labels for the sample images.


#Files included
	•	Fashion_MNIST_Classification.ipynb: Python script for implementing PCA and optional logistic regression.
	•	Fashion MNIST Classification Using CNN_README.md: Instructions for understanding and running the project.
	