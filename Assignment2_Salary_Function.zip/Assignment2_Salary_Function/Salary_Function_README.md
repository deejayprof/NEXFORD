README.md
# Salary Function

## Description
This project processes salary data to retrieve employee details, handle errors, and export data in Python. Additionally, it includes an R script to unzip and display exported employee data.

## Features
- Import salary data from a CSV file.
- Retrieve employee details using Python.
- Handle errors gracefully.
- Export employee details to a CSV file and zip it.
- Use R to unzip the folder and display data.

## How to Use

## Python
Run the Jupyter Notebook (Salary_function.ipynb):
Import salary data.
Use get_employee_details() to retrieve employee details.
Use export_employee_to_csv() to export data.

## R
Run the R script (Salary_Function.R):
Unzip the exported folder.
Load and display employee data from the CSV file.
Files Included

salary_function.ipynb: Python notebook.
unzip_and_display.R: R script.
README.md: Instructions.
