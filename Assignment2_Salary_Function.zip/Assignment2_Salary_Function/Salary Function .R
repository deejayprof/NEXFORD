# Unzip the folder
unzip("Employee Profile.zip", exdir = "Employee_Profile_Unzipped")

# Load the employee details CSV file
file_path <- list.files("Employee_Profile_Unzipped", full.names = TRUE, pattern = "\\.csv$")
employee_data <- read.csv(file_path)

# Display the data
print(employee_data)
